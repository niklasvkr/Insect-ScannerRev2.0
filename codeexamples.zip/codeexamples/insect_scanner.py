from time import sleep
from picamera2 import Picamera2
import RPi.GPIO as GPIO
import datetime

# to enable start from power up: "crontab -e"
# "@reboot sleep 120;  /usr/bin/python3 /home/gruenspecht/workspace/insect_scanner.py"

WHITE_PIN = 16
UV_PIN = 21
UV_TIME = 24 #240
SLEEP_TIME = 60 #600

GPIO.setmode(GPIO.BCM)

GPIO.setup(WHITE_PIN, GPIO.OUT)
GPIO.setup(UV_PIN, GPIO.OUT)

picam2 = Picamera2()
config = picam2.create_still_configuration()
picam2.configure(config)

GPIO.output(UV_PIN, GPIO.HIGH)

while True:
    sleep(SLEEP_TIME)
    picam2.start()
    GPIO.output(UV_PIN, GPIO.LOW) 
    GPIO.output(WHITE_PIN, GPIO.HIGH)
    sleep(5)
    timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H_%M_%S')
    picam2.capture_file(f"/home/gruenspecht/Pictures/insectscanner/img{timestamp}.jpg")
    print(f"Bild aufgenommen: img{timestamp}")
    picam2.stop()
    GPIO.output(WHITE_PIN, GPIO.LOW)
    GPIO.output(UV_PIN, GPIO.HIGH)

