
"""
import serial

ser = serial.Serial('/dev/ttyS0', 9600, timeout=5)
print("Starte GPS-Auslesung... (STRG+C zum Beenden)")
try:
    while True:
        line = ser.readline().decode('ascii', errors='replace').strip()
        if line:
            print(f"Empfangen: {line}")
except KeyboardInterrupt:
    print("\nProgramm beendet.")
finally:
    ser.close()


"""
import serial
import csv
import time
import pynmea2
from datetime import datetime, timedelta
import pytz



def get_fresh_gga(ser):
    # Puffer leeren
    ser.reset_input_buffer()
    # Auf den nächsten GGA warten
    while True:
        line = ser.readline().decode('ascii', errors='replace').strip()
        if line.startswith('$GNGGA') or line.startswith('$GPGGA'):
            try:
                return pynmea2.parse(line)
            except pynmea2.ParseError:
                pass

def get_fresh_gsv(ser, timeout=1):
    # Ähnlich, Puffer ggf. leeren oder in einer kurzen Schleife lesen
    start = time.time()
    while time.time() - start < timeout:
        line = ser.readline().decode('ascii', errors='replace').strip()
        if line.startswith('$GNGSV') or line.startswith('$GPGSV'):
            try:
                return pynmea2.parse(line)
            except pynmea2.ParseError:
                pass
    return None

def main():
    # Seriellen Port und Baudrate ggf. anpassen
    ser = serial.Serial('/dev/ttyS0', 9600, timeout=5)
    csv_filename = 'gps_daten.csv'
    
    germany_tz = pytz.timezone('Europe/Berlin')
    # CSV-Datei öffnen und Header schreiben (falls Datei neu erstellt wird)
    with open(csv_filename, mode='a', newline='') as csvfile:
        writer = csv.writer(csvfile)
        
        # Schreibe den Header, falls die Datei leer ist
        if csvfile.tell() == 0:
            writer.writerow(["GPS_Time_Germany", "Latitude", "Longitude", "Altitude", "Satellites_used", "Satellites_in_view"])
        
        print("Starte das Auslesen der GPS-Daten. Strg+C zum Beenden.")
        
        try:
            while True:
                gga_msg = get_fresh_gga(ser)
                gsv_msg = get_fresh_gsv(ser)
                latitude = gga_msg.latitude
                longitude = gga_msg.longitude
                altitude = gga_msg.altitude
                satellites_used = gga_msg.num_sats  # Anzahl der für den Fix verwendeten Satelliten
                # GPS-Zeit auslesen und in lesbares Format umwandeln (UTC)
                gps_time = gga_msg.timestamp
                if gps_time:
                    # Erzeuge vollständigen Zeitstempel mit heutigem Datum und GPS-Zeit
                    gps_timestamp = datetime.utcnow().replace(hour=gps_time.hour, minute=gps_time.minute, second=gps_time.second, microsecond=0)
                    
                    # Zeit in deutsche Zeit (MEZ/MESZ) umwandeln
                    gps_timestamp = gps_timestamp.replace(tzinfo=pytz.utc).astimezone(germany_tz)
                    gps_timestamp_str = gps_timestamp.strftime("%Y-%m-%d %H:%M:%S (%Z)")
                else:
                    gps_timestamp_str = "N/A"
                
                

                if gsv_msg is not None and hasattr(gsv_msg, 'num_sv_in_view'):
                    satellites_in_view = gsv_msg.num_sv_in_view
                else:
                    # Falls kein GSV-Satz verfügbar, als Fallback den GGA-Wert nutzen
                    satellites_in_view = satellites_used

                
                # Schreibe die ausgelesenen Daten in die CSV-Datei
                writer.writerow([gps_timestamp_str, latitude, longitude, altitude, satellites_used, satellites_in_view])
                csvfile.flush()  # sofortiges Schreiben in die Datei
                print(f"GPS_Time_Germany{gps_timestamp_str} - Lat: {latitude}, Lon: {longitude}, Alt: {altitude}, "
                      f"Sat_used: {satellites_used}, Sat_view: {satellites_in_view}")
                
                # Warte 15 Sekunden, bevor die nächsten Daten erfasst werden
                time.sleep(15)
        except KeyboardInterrupt:
            print("\nProgramm beendet.")
        finally:
            ser.close()

if __name__ == "__main__":
    main()

#"""
